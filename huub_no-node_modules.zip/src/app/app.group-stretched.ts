import {Component} from '@angular/core';

/**
 * @title Tab group with stretched labels
 */
@Component({
  selector: 'tab-group-stretched',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class TabGroupStretchedExample {}
