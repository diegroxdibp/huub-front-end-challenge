import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-huub-nav-home',
  templateUrl: './huub-nav-home.component.html',
  styleUrls: ['./huub-nav-home.component.scss']
})
export class HuubNavHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
