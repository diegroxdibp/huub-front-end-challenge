import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-huub-nav-products',
  templateUrl: './huub-nav-products.component.html',
  styleUrls: ['./huub-nav-products.component.scss']
})
export class HuubNavProductsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
