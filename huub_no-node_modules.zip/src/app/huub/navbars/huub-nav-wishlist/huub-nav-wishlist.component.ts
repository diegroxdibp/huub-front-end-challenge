import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-huub-nav-wishlist',
  templateUrl: './huub-nav-wishlist.component.html',
  styleUrls: ['./huub-nav-wishlist.component.scss']
})
export class HuubNavWishlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
