import { MinMaxPipe } from './min-max.pipe';

describe('MinMaxPipe', () => {
  it('create an instance', () => {
    const pipe = new MinMaxPipe();
    expect(pipe).toBeTruthy();
  });
});
